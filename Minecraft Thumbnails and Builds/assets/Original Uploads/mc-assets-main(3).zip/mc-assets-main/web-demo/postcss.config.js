module.exports = {
    plugins: {
      tailwindcss: {},
    },
  };
