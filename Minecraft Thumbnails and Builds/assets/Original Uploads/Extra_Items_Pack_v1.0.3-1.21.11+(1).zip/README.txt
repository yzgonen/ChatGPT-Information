===================================================================
 DootMan27's Extra Items Pack - ITEM RENAME LIST
===================================================================

HOW IT WORKS
------------
This is a Minecraft resource pack — it changes textures and models,
it does not add new items or IDs. Every "new weapon" in this pack 
is a vanilla item with a different look to it, based on it's name.

To get one:
  1. Take the base vanilla item listed below (e.g. an Iron Sword).
  2. Rename it using an Anvil, OR give it a custom name via command,
     e.g.  /give @s iron_sword[custom_name='"Katana"']
  3. The item will now display as that weapon's custom model, while
     still functioning as the base item underneath (an Iron Sword
     named "Katana" still has iron stats).

Renaming is CASE SENSITIVE and must match a listed name exactly -
extra spaces, punctuation, or wrong capitalization will fall back
to the item's normal look.

===================================================================
 WOODEN TOOLS
===================================================================
Wooden Axe:
  "Hatchet" / "Wooden Hatchet"          -> Wooden Hatchet

Wooden Pickaxe:
  "Hammer" / "Wooden Hammer"            -> Wooden Hammer

Wooden Shovel:
  "Trowel" / "Wooden Trowel"            -> Wooden Trowel

Wooden Sword:
  "Club" / "Wooden Club"                -> Wooden Club

Wooden Spear (if you have the custom Spear item):
  "Crude Spear" / "Wooden Crude Spear"  -> Wooden Crude Spear

===================================================================
 STONE TOOLS
===================================================================
Stone Axe:
  "Hatchet" / "Stone Hatchet"           -> Stone Hatchet

Stone Pickaxe:
  "Hammer" / "Stone Hammer"             -> Stone Hammer

Stone Shovel:
  "Trowel" / "Stone Trowel"             -> Stone Trowel

Stone Sword:
  "Club" / "Stone Club"                 -> Stone Club

Stone Spear:
  "Crude Spear" / "Stone Crude Spear"   -> Stone Crude Spear

===================================================================
 IRON TOOLS
===================================================================
Iron Axe:
  "Battle Axe" / "Iron Battle Axe"        -> Battle Axe
  "Minotaur Axe" / "Iron Minotaur Axe"    -> Minotaur Axe
  "Reforged Axe" / "Iron Reforged Axe"    -> Reforged Axe

Iron Pickaxe:
  "Fish" / "Fish-axe" / "Iron Fish" / "Iron Fish-axe"  -> Fish Pickaxe
  "Hammer" / "Iron Hammer"                             -> Hammer

Iron Shovel:
  "Spade" / "Iron Spade"                -> Spade

Iron Spear:
  "Fleur-de-lis" / "Iron Fleur-de-lis"  -> Fleur-de-lis
  "Lance" / "Iron Lance"                -> Lance

Iron Sword:
  "Claymore" / "Iron Claymore"          -> Claymore
  "Club" / "Iron Club"                  -> Club
  "Dagger" / "Iron Dagger"              -> Dagger
  "Falchion" / "Iron Falchion"          -> Falchion
  "Flamberge" / "Iron Flamberge"        -> Flamberge
  "Kama" / "Iron Kama"                  -> Kama
  "Rapier" / "Iron Rapier"              -> Rapier
  "Scythe" / "Iron Scythe"              -> Scythe
  "Shortsword" / "Iron Shortsword"      -> Shortsword
  "Sickle" / "Iron Sickle"              -> Sickle
  "Katana" / "Iron Katana"              -> Katana

===================================================================
 GOLDEN TOOLS
===================================================================
Golden Axe:
  "Battle Axe" / "Golden Battle Axe"        -> Battle Axe
  "Minotaur Axe" / "Golden Minotaur Axe"    -> Minotaur Axe
  "Reforged Axe" / "Golden Reforged Axe"    -> Reforged Axe

Golden Pickaxe:
  "Fish" / "Fish-axe" / "Golden Fish" / "Golden Fish-axe"  -> Fish Pickaxe
  "Hammer" / "Golden Hammer"                               -> Hammer

Golden Shovel:
  "Spade" / "Golden Spade"              -> Spade

Golden Spear:
  "Fleur-de-lis" / "Golden Fleur-de-lis"  -> Fleur-de-lis
  "Lance" / "Golden Lance"                -> Lance

Golden Sword:
  "Claymore" / "Golden Claymore"        -> Claymore
  "Club" / "Golden Club"                -> Club
  "Dagger" / "Golden Dagger"            -> Dagger
  "Falchion" / "Golden Falchion"        -> Falchion
  "Flamberge" / "Golden Flamberge"      -> Flamberge
  "Kama" / "Golden Kama"                -> Kama
  "Rapier" / "Golden Rapier"            -> Rapier
  "Scythe" / "Golden Scythe"            -> Scythe
  "Shortsword" / "Golden Shortsword"    -> Shortsword
  "Sickle" / "Golden Sickle"            -> Sickle
  "Katana" / "Golden Katana"            -> Katana
  "Hero" / "Hero Sword"                 -> Hero Sword

===================================================================
 DIAMOND TOOLS
===================================================================
Diamond Axe:
  "Battle Axe" / "Diamond Battle Axe"        -> Battle Axe
  "Minotaur Axe" / "Diamond Minotaur Axe"    -> Minotaur Axe
  "Reforged Axe" / "Diamond Reforged Axe"    -> Reforged Axe
  "The Axe"                                  -> The Axe

Diamond Pickaxe:
  "Fish" / "Fish-axe" / "Diamond Fish" / "Diamond Fish-axe"  -> Fish Pickaxe
  "Hammer" / "Diamond Hammer"                                -> Hammer

Diamond Shovel:
  "Spade" / "Diamond Spade"             -> Spade

Diamond Spear:
  "Fleur-de-lis" / "Diamond Fleur-de-lis"  -> Fleur-de-lis
  "Lance" / "Diamond Lance"                -> Lance

Diamond Sword:
  "Claymore" / "Diamond Claymore"       -> Claymore
  "Club" / "Diamond Club"               -> Club
  "Dagger" / "Diamond Dagger"           -> Dagger
  "Falchion" / "Diamond Falchion"       -> Falchion
  "Flamberge" / "Diamond Flamberge"     -> Flamberge
  "Kama" / "Diamond Kama"               -> Kama
  "Rapier" / "Diamond Rapier"           -> Rapier
  "Scythe" / "Diamond Scythe"           -> Scythe
  "Shortsword" / "Diamond Shortsword"   -> Shortsword
  "Sickle" / "Diamond Sickle"           -> Sickle
  "Katana" / "Diamond Katana"           -> Katana
  "Demon" / "Demon Sword"               -> Withered Demon Sword

===================================================================
 NETHERITE TOOLS
===================================================================
Netherite Axe:
  "Battle Axe" / "Netherite Battle Axe"      -> Battle Axe
  "Minotaur Axe" / "Netherite Minotaur Axe"  -> Minotaur Axe
  "Reforged Axe" / "Netherite Reforged Axe"  -> Reforged Axe
  "The Axe"                                  -> The Axe
  "Fire Axe" / "Pulaski"                     -> Fire Axe
  "Corn" / "Corn Axe"                        -> Corn Axe

Netherite Pickaxe:
  "Fish" / "Fish-axe" / "Netherite Fish" / "Netherite Fish-axe"  -> Fish Pickaxe
  "Hammer" / "Netherite Hammer"                                  -> Hammer

Netherite Shovel:
  "Spade" / "Netherite Spade"           -> Spade

Netherite Spear:
  "Fleur-de-lis" / "Netherite Fleur-de-lis"  -> Fleur-de-lis
  "Lance" / "Netherite Lance"                -> Lance
  "Spear of Justice"                         -> Spear of Justice
  "Crimson" / "Crimson Spear"                -> Silly Spear

Netherite Sword:
  "Claymore" / "Netherite Claymore"     -> Claymore
  "Club" / "Netherite Club"             -> Club
  "Dagger" / "Netherite Dagger"         -> Dagger
  "Falchion" / "Netherite Falchion"     -> Falchion
  "Flamberge" / "Netherite Flamberge"   -> Flamberge
  "Kama" / "Netherite Kama"             -> Kama
  "Rapier" / "Netherite Rapier"         -> Rapier
  "Scythe" / "Netherite Scythe"         -> Scythe
  "Shortsword" / "Netherite Shortsword" -> Shortsword
  "Sickle" / "Netherite Sickle"         -> Sickle
  "Katana" / "Netherite Katana"         -> Katana
  "Demon" / "Demon Sword"               -> Demon Sword
  "Grass" / "Grass Sword" / "Grass Katana"  -> Grass Sword
  "Root" / "Root Sword"                 -> Root Sword
  "Amethyst" / "Amethyst Sword"         -> Amethyst Sword
  "Ice" / "Ice Sword"                   -> Ice Sword
  "Fire" / "Fire Sword"                 -> Fire Sword
  "Aether" / "Aether Sword"             -> Aether Sword
  "Queen's Claymore" / "Queen's Blade"  -> Queen's Claymore
  "Lunar Claymore" / "Lunar Blade"      -> Lunar Claymore

===================================================================
 MACE
===================================================================
  "Justice" / "Justice Mace" / "Mace of Justice" /
    "Justice Hammer" / "Hammer of Justice"        -> Justice Mace
  "Hammer" / "Hammer Mace"                        -> Hammer Mace
  "Double Edged Scythe" / "Dual Scythe"           -> Dual Scythe Mace
  "Crowbar"                                       -> Crowbar Mace
  "Knight's Mace" / "Knight Mace"                 -> Knight's Mace

===================================================================
 BOW
===================================================================
  "Harp" / "Harp Bow"                   -> Harp Bow

===================================================================
 NAME TAGS (Easter Eggs)
===================================================================
Rename a Name Tag to one of these exact names for a fun texture:
  Grumm
  Dinnerbone
  jeb_
  Johnny
  Toast

===================================================================
 TOTEM OF UNDYING
===================================================================
  "Crucifix" / "Crucifix Totem"                   -> Crucifix Totem

===================================================================
 NOTES
===================================================================
- If a rename doesn't seem to work, double check for typos,
  extra spaces, or capitalization - names must match exactly.
- Copper tools in this pack visually oxidize over time, just like
  copper blocks, giving them a weathered look as they age.
- Goat Horns have been given more visually distinct textures so
  the different horn variants are easier to tell apart.
