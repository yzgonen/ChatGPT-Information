Thanks for downloading the alpha release of my String Lights project!

Troubleshooting and Use:

* Make sure the pack is at the TOP of your resource pack list. This should have zero effect on other running packs. *

To access the strings, renamed a GLOWSTONE DUST in an ANVIL to one of the following, being sure to use CAPS (ignore the brackets):

Basics (Use these as a Modular system):
Yellow. SL (Large)
   SLT (Large Twinkle)
   SLM (Mini)
   SLMI (Single Block)
   SLWRP (Wrap)
   RT (Random across block surface)
Red. SLR (Large)
   SLRT (Large Twinkle)
   SLMR (Mini)
   SLMIR (Single Block)
   SLWRPR (Wrap)
   RTR (Random across block surface)
Orange. SLO (Large)
   SLOT (Large Twinkle)
   SLMO (Mini)
   SLMIO (Single Block)
   SWRPO (Wrap)
   RTO (Random across block surface)
Green. SLLG (Large)
   SLLGT (Large Twinkle)
   SLMLG (Mini)
   SLMIG (Single Block)
   SLWRPG (Wrap)
   RTG (Random across block surface)
Light Blue. SLLB (Large)
   SLLBT (Large Twinkle)
   SLMLB (Mini)
   SLMILB (Single Block)
   SLWRPLB (Wrap)
   RTLB (Random across block surface)
Blue. SLB (Large)
   SLBT (Large Twinkle)
   SLMB (Mini)
   SLMIB (Single Block)
   SLWRPB (Wrap)
   RTB (Random across block surface)
Purple.  SLP (Large)
    SLPT (Large Twinkle)
    SLMP (Mini)
    SLMIP (Single Block)
    SLWRPP (Wrap)
    RTP (Random across block surface)
Magenta.  SLMM (Mini)
    SLMIM (Single Block)
    SLWRPM (Wrap)
    RTM (Random across block surface)
Pink.  SLPK (Large)
    SLPKT (Large Twinkle)
    SLMPK (Mini)
    SLMIPK (Single Block)
    SLWRPPK (Wrap)
    RTPK (Random across block surface)

Chained  Lanterns:
26. SLANT
27. SLANTSOUL
28. SLANTCOPPER
29. SLANTCOPPER1
30. SLANTCOPPER2

Halloween:
31. JACK  (Pale Oak Static)
32. JACKS (Pale Oak Flickering)
33. JACKO (on carved pumpkin)
34. GRAVE (on carved pumpkin)
35. GHOSTIE (on carved pumpkin)

Christmas:
35. SLMCC
36. SLMC
37. SLMCS
38. SLMG
64. TREE
65. SCONCE
66. CANDELABRA

Chinese New Year:
39. SLCNYR
40. SLCNYW

Día de Muertos:
41. DDM

Special:
41. LLAMA
42. ARM
43. BDAY
44. SLFLOW
45. SLFLOWPOP

Flags:
45. FLAGRED
46. FLAGORANGE
47. FLAGYELLOW
48. FLAGGREEN
49. FLAGLIME
50. FLAGLIGHTBLUE
51. FLAGCYAN
52. FLAGBLUE
53. FLAGPURPLE
54. FLAGMAGENTA
55. FLAGPINK

Clothes:
56. DRY
57. DRY1
58. DRY2
59. DRY3
60. DRY4

Things:
61. LANTERN (on stained green glass pane)
62. WAVE
63. WAVEOFFSET

Bonuses:
67. BDAYHAT (on carved pumpkin)
68. ARMPLUSH (on carved pumpkin)
69. LLAMAPLUSH (on carved pumpkin)
70. FLOWERCROWN (on carved pumpkin)
70. FLOWERCROWNP (on carved pumpkin)
71. LUCIA (on carved pumpkin)

As the pack is updated this list will be updated.

Credits:

The style of this pack was inspired by user Wondarkus and their pack: (https://modrinth.com/resourcepack/garland)
Credits and Permission was received from user Thanos of the Pixel Consistency project for the LLAMA texture! (https://modrinth.com/resourcepack/pixel-consistency)
User P4ncake for the inspiration for an additional lighting feature within the pack, now accessible within survival gameplay! (https://modrinth.com/resourcepack/light-thingy)